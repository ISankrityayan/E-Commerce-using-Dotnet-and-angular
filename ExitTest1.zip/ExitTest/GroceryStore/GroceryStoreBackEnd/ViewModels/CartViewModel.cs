﻿namespace GroceryStoreBackEnd.ViewModels
{
    public class CartViewModel
    {
        public int UserId { get; set; }
        public int ProductId { get; set; }
        public int Quantity { get; set; }
    }
}