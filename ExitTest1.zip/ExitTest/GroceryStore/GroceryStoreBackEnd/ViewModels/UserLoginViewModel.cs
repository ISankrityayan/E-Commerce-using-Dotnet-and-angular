﻿namespace GroceryStoreBackEnd.ViewModels
{
    public class UserLoginViewModel
    {
        public string UserEmail { get; set; }
        public string Password { get; set; }
    }
}
