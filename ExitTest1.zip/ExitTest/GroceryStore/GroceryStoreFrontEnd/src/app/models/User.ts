export interface User {
  userName: string;
  userEmail: string;
  password: string;
  userId: number;
  userRole: string;
  phoneNumber: string;
}
