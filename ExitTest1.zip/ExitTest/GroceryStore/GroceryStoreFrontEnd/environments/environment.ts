export const environment = {
  production: false,
  baseApiUrl: 'https://localhost:5001/api/',
  baseImageApiUrl: 'https://localhost:5001/api/product/image/',
};
