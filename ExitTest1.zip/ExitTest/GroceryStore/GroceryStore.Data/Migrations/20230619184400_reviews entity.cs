﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace GroceryStore.DataLayer.Migrations
{
    public partial class reviewsentity : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
