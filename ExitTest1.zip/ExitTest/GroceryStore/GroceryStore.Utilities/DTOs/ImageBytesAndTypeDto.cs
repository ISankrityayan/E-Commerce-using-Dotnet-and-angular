﻿namespace GroceryStoreCore.DTOs
{
    public class ImageBytesAndTypeDto
    {
        
        public byte[] Bytes { get; set; }

        public string ContentType { get; set; }
    }
}
